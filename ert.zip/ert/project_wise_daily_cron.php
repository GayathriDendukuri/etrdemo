<?php
/******************************************************************
 * Ideabytes Software India Pvt Ltd.                              *
 * 50 Jayabheri Enclave, Gachibowli, HYD                          *
 * Created Date : 22/01/2014                                      *
 * Created By : Gayathri                                          *
 * Vision : IB Innovation                                         *
 * Modified by : Gayathri     Date : 22/01/2014    Version : V1   *
 * Description : page management for admin                        *
 *****************************************************************/
 
include("includes/header.inc.php");

if($logininfo['admin_type']!="1"){
	header("Location: index.php");
	exit;
}
include("classes/project_wise_daily_cron.class.php");

$objMessages = new Messages();
$objProjectWiseDailyCron = new PROJECT_WISE_DAILY_CRON();

$moduleLabel = "DailyCron"; 

	
$projectId = 1;

$userData = $objProjectWiseDailyCron->getEmployeeNotReported($projectId);

print_r($userData);exit;
foreach($userData as $data){
	
}

 
?>