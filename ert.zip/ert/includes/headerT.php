<?php 

/* Includes config,db and table definitions and common functions files */
include("dbconfig.php");   //Creates db connection
include("configuration.php");  //Default configurations
include("tables.php");  //Table configurations
//exit;
?>
