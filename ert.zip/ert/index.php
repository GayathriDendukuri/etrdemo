<?php

header('Location: project.php');

?>